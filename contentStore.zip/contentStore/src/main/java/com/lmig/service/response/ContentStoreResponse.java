package com.lmig.service.response;

import java.util.ArrayList;
import java.util.List;

import com.lmig.docsol.entity.ClaimDocument;

public class ContentStoreResponse {
	
	private int claimsCount;
	List<ClaimDocument> claimDocument;
	
	public ContentStoreResponse() {
		claimDocument = new ArrayList<ClaimDocument>();
	}
	public void addDocument(ClaimDocument doc){
		claimDocument.add(doc);	
	}
	
	public int getClaimsCount() {
		return claimsCount;
	}
	
	public void setClaimsCount(int claimsCount) {
		this.claimsCount = claimsCount;
	}
	
	public List<ClaimDocument> getClaimDocument() {
		return claimDocument;
	}
	
	public void setClaimDocument(List<ClaimDocument> claimDocument) {
		this.claimDocument = claimDocument;
	}
	
}
