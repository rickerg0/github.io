package com.lmig.docsol.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the uscmdocumentbase database table.
 * 
 */
@Entity
@NamedQuery(name="Uscmdocumentbase.findAll", query="SELECT u FROM Uscmdocumentbase u")
public class Uscmdocumentbase implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int documentBase_id;

	@Temporal(TemporalType.DATE)
	private Date archiveMarkedDate;

	private String clientName;

	private String clientRequestID;

	private String comments;

	@Temporal(TemporalType.DATE)
	private Date complianceMarkedDate;

	private String complianceModifier;

	private String contentType;

	private String contentURL;

	@Temporal(TemporalType.DATE)
	private Date created;

	private String creator;

	@Temporal(TemporalType.DATE)
	private Date deleteMarkedDate;

	private String deleteModifier;

	private String description;

	@Temporal(TemporalType.DATE)
	private Date documentDate;

	private int ecmID;

	private String filename;

	@Temporal(TemporalType.DATE)
	private Date holdMarkedDate;

	private String holdModifier;

	private Integer isContentIndexed;
	
	private Integer isIndexed;


	@Temporal(TemporalType.DATE)
	private Date modified;

	private String modifier;

	@Temporal(TemporalType.DATE)
	private Date originalLoadDateTime;

	@Temporal(TemporalType.DATE)
	private Date removeAfterDate;

	private String retentionRecordClass;

	private String sourceSystemName;

	private String sourceSystemTransID;

	private Integer suppress;

	//bi-directional many-to-one association to Namevalue
	@OneToMany(cascade = CascadeType.ALL,mappedBy="uscmdocumentbaseBean")
	private Set<Namevalue> namevalues;

	public Uscmdocumentbase() {
		namevalues = new HashSet<Namevalue>();
	}

	public int getDocumentBase_id() {
		return this.documentBase_id;
	}

	public void setDocumentBase_id(int documentBase_id) {
		this.documentBase_id = documentBase_id;
	}

	public Date getArchiveMarkedDate() {
		return this.archiveMarkedDate;
	}

	public void setArchiveMarkedDate(Date archiveMarkedDate) {
		this.archiveMarkedDate = archiveMarkedDate;
	}

	public String getClientName() {
		return this.clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientRequestID() {
		return this.clientRequestID;
	}

	public void setClientRequestID(String clientRequestID) {
		this.clientRequestID = clientRequestID;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getComplianceMarkedDate() {
		return this.complianceMarkedDate;
	}

	public void setComplianceMarkedDate(Date complianceMarkedDate) {
		this.complianceMarkedDate = complianceMarkedDate;
	}

	public String getComplianceModifier() {
		return this.complianceModifier;
	}

	public void setComplianceModifier(String complianceModifier) {
		this.complianceModifier = complianceModifier;
	}

	public String getContentType() {
		return this.contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentURL() {
		return this.contentURL;
	}

	public void setContentURL(String contentURL) {
		this.contentURL = contentURL;
	}

	public Date getCreated() {
		return this.created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getDeleteMarkedDate() {
		return this.deleteMarkedDate;
	}

	public void setDeleteMarkedDate(Date deleteMarkedDate) {
		this.deleteMarkedDate = deleteMarkedDate;
	}

	public String getDeleteModifier() {
		return this.deleteModifier;
	}

	public void setDeleteModifier(String deleteModifier) {
		this.deleteModifier = deleteModifier;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDocumentDate() {
		return this.documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public int getEcmID() {
		return this.ecmID;
	}

	public void setEcmID(int ecmID) {
		this.ecmID = ecmID;
	}

	public String getFilename() {
		return this.filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Date getHoldMarkedDate() {
		return this.holdMarkedDate;
	}

	public void setHoldMarkedDate(Date holdMarkedDate) {
		this.holdMarkedDate = holdMarkedDate;
	}

	public String getHoldModifier() {
		return this.holdModifier;
	}

	public void setHoldModifier(String holdModifier) {
		this.holdModifier = holdModifier;
	}

	public Integer getIsContentIndexed() {
		return this.isContentIndexed;
	}

	public void setIsContentIndexed(Integer isContentIndexed) {
		this.isContentIndexed = isContentIndexed;
	}

	public Integer getIsIndexed() {
		return this.isIndexed;
	}

	public void setIsIndexed(Integer isIndexed) {
		this.isIndexed = isIndexed;
	}

	public Date getModified() {
		return this.modified;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public Date getOriginalLoadDateTime() {
		return this.originalLoadDateTime;
	}

	public void setOriginalLoadDateTime(Date originalLoadDateTime) {
		this.originalLoadDateTime = originalLoadDateTime;
	}

	public Date getRemoveAfterDate() {
		return this.removeAfterDate;
	}

	public void setRemoveAfterDate(Date removeAfterDate) {
		this.removeAfterDate = removeAfterDate;
	}

	public String getRetentionRecordClass() {
		return this.retentionRecordClass;
	}

	public void setRetentionRecordClass(String retentionRecordClass) {
		this.retentionRecordClass = retentionRecordClass;
	}

	public String getSourceSystemName() {
		return this.sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

	public String getSourceSystemTransID() {
		return this.sourceSystemTransID;
	}

	public void setSourceSystemTransID(String sourceSystemTransID) {
		this.sourceSystemTransID = sourceSystemTransID;
	}

	public Integer getSuppress() {
		return this.suppress;
	}

	public void setSuppress(Integer suppress) {
		this.suppress = suppress;
	}

	public Set<Namevalue> getNamevalues() {
		return this.namevalues;
	}

	public void setNamevalues(Set<Namevalue> namevalues) {
		this.namevalues = namevalues;
	}

	public Namevalue addNamevalue(Namevalue namevalue) {
		getNamevalues().add(namevalue);
		namevalue.setUscmdocumentbaseBean(this);

		return namevalue;
	}

	public Namevalue removeNamevalue(Namevalue namevalue) {
		getNamevalues().remove(namevalue);
		namevalue.setUscmdocumentbaseBean(null);

		return namevalue;
	}

}