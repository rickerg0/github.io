package com.lmig.docsol.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lmig.docsol.entity.ClaimDocument;
import com.lmig.docsol.service.ContentStoreService;
import com.lmig.service.response.ContentStoreResponse;



@RequestMapping("/contentStore")
public class ClaimDocumentController {

	
	private static final long serialVersionUID = 1L;
	private final static Logger logger = Logger.getLogger(ClaimDocumentController.class);

	@Autowired
	private ContentStoreService contentStoreService;
	
	@RequestMapping(value="/{store}", method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<?> storeDocument(HttpServletResponse httpResponse, 
			@PathVariable(value="document") ClaimDocument document) {

		
		return new ResponseEntity<ContentStoreResponse>(contentStoreService.insertClaimDocument(document),HttpStatus.OK);
	}
	
		
	@RequestMapping(value="/listClaimsDocuments", method=RequestMethod.GET)
	public @ResponseBody ResponseEntity<?> getClaimsDocuments(HttpServletResponse httpResponse, 
			 @PathVariable(value="number") String number) {
	
		return new ResponseEntity<List<ClaimDocument>>(contentStoreService.findClaimDocumentByClaimNumber(number),HttpStatus.OK);
	}
	
	@RequestMapping(value="/countClaimsDocuments", method=RequestMethod.GET)
	public @ResponseBody ResponseEntity<?> countClaimsDocuments(HttpServletResponse httpResponse, 
			 @PathVariable(value="number") String number) {
	
		return new ResponseEntity<ContentStoreResponse>(contentStoreService.countClaimDocumentByClaimNumber(number),HttpStatus.OK);
	}
}
