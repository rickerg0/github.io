package com.lmig.docsol.contentStore.springconfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@ComponentScan("com.lmig.docsol")
@PropertySource("classpath:application.properties")
@Import({DispatcherConfig.class, DatabaseConfig.class})
public class ApplicationConfig extends WebMvcConfigurerAdapter {
	

}
