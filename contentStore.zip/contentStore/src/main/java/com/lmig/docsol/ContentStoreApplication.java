package com.lmig.docsol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

import com.lmig.docsol.contentStore.springconfig.DatabaseConfig;
import com.lmig.docsol.contentStore.springconfig.DispatcherConfig;

@SpringBootApplication

@Configuration
@ComponentScan("com.lmig")
@PropertySource("classpath:application.properties")
@Import({DispatcherConfig.class, DatabaseConfig.class})
public class ContentStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContentStoreApplication.class, args);
	}
}
