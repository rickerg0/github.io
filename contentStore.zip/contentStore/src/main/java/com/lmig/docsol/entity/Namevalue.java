package com.lmig.docsol.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the namevalues database table.
 * 
 */
@Entity
@Table(name="namevalues")
@NamedQuery(name="Namevalue.findAll", query="SELECT n FROM Namevalue n")
public class Namevalue implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int nameValue_id;

	private String name;

	private String value;

	//bi-directional many-to-one association to Uscmdocumentbase
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="uscmdocumentbase")
	private Uscmdocumentbase uscmdocumentbaseBean;

	public Namevalue() {
	}
	
	public Namevalue(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public int getNameValue_id() {
		return this.nameValue_id;
	}

	public void setNameValue_id(int nameValue_id) {
		this.nameValue_id = nameValue_id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Uscmdocumentbase getUscmdocumentbaseBean() {
		return this.uscmdocumentbaseBean;
	}

	public void setUscmdocumentbaseBean(Uscmdocumentbase uscmdocumentbaseBean) {
		this.uscmdocumentbaseBean = uscmdocumentbaseBean;
	}

}