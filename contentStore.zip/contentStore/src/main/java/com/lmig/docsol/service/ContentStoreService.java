package com.lmig.docsol.service;

import java.util.List;
import com.lmig.docsol.entity.ClaimDocument;
import com.lmig.service.response.ContentStoreResponse;

public interface ContentStoreService {

	List<ClaimDocument> findClaimDocumentByPolicyNumber(String policyNumber);

	List<ClaimDocument> findClaimDocumentByClaimNumber(String claimNumber);
	
	ContentStoreResponse countClaimDocumentByClaimNumber(String claimNumber);
	

	ContentStoreResponse insertClaimDocument(ClaimDocument cd);
}
