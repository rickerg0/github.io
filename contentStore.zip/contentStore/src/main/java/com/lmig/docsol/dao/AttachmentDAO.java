package com.lmig.docsol.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lmig.docsol.entity.Attachment;

@Transactional()
public interface AttachmentDAO extends JpaRepository<Attachment,Integer>{

}
