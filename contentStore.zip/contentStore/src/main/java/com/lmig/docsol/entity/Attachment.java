package com.lmig.docsol.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the attachment database table.
 * 
 */
@Entity
@NamedQuery(name="Attachment.findAll", query="SELECT a FROM Attachment a")
public class Attachment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int attachment_id;

	private int childdocBase;

	private int parentdocBase;

	public Attachment() {
	}

	public int getAttachment_id() {
		return this.attachment_id;
	}

	public void setAttachment_id(int attachment_id) {
		this.attachment_id = attachment_id;
	}

	public int getChilddocBase() {
		return this.childdocBase;
	}

	public void setChilddocBase(int childdocBase) {
		this.childdocBase = childdocBase;
	}

	public int getParentdocBase() {
		return this.parentdocBase;
	}

	public void setParentdocBase(int parentdocBase) {
		this.parentdocBase = parentdocBase;
	}

}