package com.lmig.docsol.dao;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.lmig.docsol.entity.ClaimDocument;

@Transactional("contentStoreTransactionManager")
public interface ClaimDocumentDAO extends JpaRepository<ClaimDocument,Integer>{

	List<ClaimDocument> findClaimDocumentByPolicyNumber(String policyNumber);
	
	List<ClaimDocument> findClaimDocumentByClaimNumber(String claimNumber);
	
}
