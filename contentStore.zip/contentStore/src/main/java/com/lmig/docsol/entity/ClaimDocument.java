package com.lmig.docsol.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the claimdocument database table.
 * 
 */
@Entity
@Table(name="claimdocument")
@NamedQuery(name="ClaimDocument.findAll", query="SELECT c FROM ClaimDocument c")
public class ClaimDocument implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int claimdocument_id;

	private String addresseeFirstName;

	private String addresseeLastName;

	private String addresseeMI;

	private String batchFilename;

	private String claimNumber;

	private String dcn;

	private String documentSubType;

	private String estimateControlNumber;

	private String estimateVersion;

	private String logNumber;

	private String policyNumber;

	private String sourceTransactionCategory;

	private String typeID;

	private String uploadedBy;

	private String xposureNumber;

	//bi-directional many-to-one association to Uscmdocumentbase
	@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	
	@JoinColumn(name="docBase")
	private Uscmdocumentbase uscmdocumentbase;

	public ClaimDocument() {
		uscmdocumentbase = new Uscmdocumentbase();
	}

	public String getAddresseeFirstName() {
		return this.addresseeFirstName;
	}

	public void setAddresseeFirstName(String addresseeFirstName) {
		this.addresseeFirstName = addresseeFirstName;
	}

	public String getAddresseeLastName() {
		return this.addresseeLastName;
	}

	public void setAddresseeLastName(String addresseeLastName) {
		this.addresseeLastName = addresseeLastName;
	}

	public String getAddresseeMI() {
		return this.addresseeMI;
	}

	public void setAddresseeMI(String addresseeMI) {
		this.addresseeMI = addresseeMI;
	}

	public String getBatchFilename() {
		return this.batchFilename;
	}

	public void setBatchFilename(String batchFilename) {
		this.batchFilename = batchFilename;
	}

	public String getClaimNumber() {
		return this.claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getDcn() {
		return this.dcn;
	}

	public void setDcn(String dcn) {
		this.dcn = dcn;
	}

	public String getDocumentSubType() {
		return this.documentSubType;
	}

	public void setDocumentSubType(String documentSubType) {
		this.documentSubType = documentSubType;
	}

	public String getEstimateControlNumber() {
		return this.estimateControlNumber;
	}

	public void setEstimateControlNumber(String estimateControlNumber) {
		this.estimateControlNumber = estimateControlNumber;
	}

	public String getEstimateVersion() {
		return this.estimateVersion;
	}

	public void setEstimateVersion(String estimateVersion) {
		this.estimateVersion = estimateVersion;
	}

	public String getLogNumber() {
		return this.logNumber;
	}

	public void setLogNumber(String logNumber) {
		this.logNumber = logNumber;
	}

	public String getPolicyNumber() {
		return this.policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getSourceTransactionCategory() {
		return this.sourceTransactionCategory;
	}

	public void setSourceTransactionCategory(String sourceTransactionCategory) {
		this.sourceTransactionCategory = sourceTransactionCategory;
	}

	public String getTypeID() {
		return this.typeID;
	}

	public void setTypeID(String typeID) {
		this.typeID = typeID;
	}

	public String getUploadedBy() {
		return this.uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getXposureNumber() {
		return this.xposureNumber;
	}

	public void setXposureNumber(String xposureNumber) {
		this.xposureNumber = xposureNumber;
	}

	public Uscmdocumentbase getUscmdocumentbase() {
		return this.uscmdocumentbase;
	}

	public void setUscmdocumentbase(Uscmdocumentbase uscmdocumentbase) {
		this.uscmdocumentbase = uscmdocumentbase;
	}

}