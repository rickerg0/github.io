package com.lmig.docsol.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lmig.docsol.dao.ClaimDocumentDAO;
import com.lmig.docsol.entity.ClaimDocument;
import com.lmig.service.response.ContentStoreResponse;

@Service
public class ContentStoreServiceImpl implements ContentStoreService{

	@Autowired
	ClaimDocumentDAO claimDocumentDAO;
	
	@Override
	public	ContentStoreResponse countClaimDocumentByClaimNumber(String claimNumber)
	{
		ContentStoreResponse csr = new ContentStoreResponse();
		csr.setClaimsCount(0);
		return csr;
	}
	
	@Override
	public List<ClaimDocument> findClaimDocumentByPolicyNumber(String policyNumber) {
		// TODO Auto-generated method stub
		return claimDocumentDAO.findClaimDocumentByPolicyNumber(policyNumber);
	}

	@Override
	public List<ClaimDocument> findClaimDocumentByClaimNumber(String claimNumber) {
		// TODO Auto-generated method stub
		return claimDocumentDAO.findClaimDocumentByClaimNumber(claimNumber);
	}

	@Override
	public ContentStoreResponse insertClaimDocument(ClaimDocument cd) {
		ClaimDocument  newClaimDocument = claimDocumentDAO.save(cd);
		ContentStoreResponse csr = new ContentStoreResponse();
		csr.addDocument(newClaimDocument);
		
		return csr;
		
	}

}
