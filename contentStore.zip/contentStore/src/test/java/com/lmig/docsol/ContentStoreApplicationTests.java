package com.lmig.docsol;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lmig.docsol.contentStore.springconfig.ApplicationConfig;
import com.lmig.docsol.entity.ClaimDocument;
import com.lmig.docsol.entity.Namevalue;
import com.lmig.docsol.service.ContentStoreService;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApplicationConfig.class })
@WebAppConfiguration
public class ContentStoreApplicationTests {
	@Autowired 
	private ContentStoreService contentStoreService;
	
	@Test
	public void contextLoads() {
		for(int i=0; i < 10; i++){
			ClaimDocument cd = new ClaimDocument();
			cd.setClaimNumber("123457"+i);
			cd.setDcn("126"+i);
			cd.getUscmdocumentbase().setClientName("smith");
			Namevalue nv = new Namevalue("name 1","value 1");
		
			cd.getUscmdocumentbase().getNamevalues().add(nv);
//			ObjectMapper mapper = new ObjectMapper();
//			
//	
//			//Object to JSON in String
//			try {
//				String jsonInString = mapper.writeValueAsString(cd);
//				System.out.println(jsonInString);
//			} catch (JsonProcessingException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
	
			contentStoreService.insertClaimDocument(cd);
		}
	}

}


